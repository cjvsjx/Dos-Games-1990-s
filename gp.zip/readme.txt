Use the following keys to drive with the keyboard:

 A - Accelerate
 Z - Brake

 < - Steer left
 > - Steer right